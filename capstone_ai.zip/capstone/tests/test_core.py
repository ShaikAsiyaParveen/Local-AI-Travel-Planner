from app.itinerary_generator import generate_itinerary


def test_itinerary_length():
    itinerary = generate_itinerary("Paris", 3, "art")
    assert len(itinerary) == 3


def test_itinerary_contains_city():
    itinerary = generate_itinerary("Rome", 1, "food")
    assert "Rome" in itinerary[0]


def test_itinerary_day_format():
    itinerary = generate_itinerary("Berlin", 2, "music")
    assert itinerary[0].startswith("Day 1")


def test_intentional_failure():
    itinerary = generate_itinerary("London", 2, "theater")
    assert len(itinerary) == 2