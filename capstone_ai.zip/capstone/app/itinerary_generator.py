def generate_itinerary(city: str, days: int, interests: str) -> list:
    """
    Generate a simple day-by-day itinerary.
    """
    itinerary = []

    for day in range(1, days + 1):
        itinerary.append(
            f"Day {day} in {city}: Explore {interests}, local food, and landmarks."
        )

    return itinerary