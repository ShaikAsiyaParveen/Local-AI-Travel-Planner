from transformers import pipeline

def get_summarizer():
    """
    Load a local summarization model.
    """
    return pipeline(
        "summarization",
        model="t5-small",
        tokenizer="t5-small"
    )

def summarize_notes(notes: str, max_length=60) -> str:
    summarizer = get_summarizer()
    summary = summarizer(
        notes,
        max_length=max_length,
        min_length=20,
        do_sample=False
    )
    return summary[0]["summary_text"]