import streamlit as st
import tempfile
from app.csv_loader import load_travel_csv
from app.summarizer import summarize_notes
from app.itinerary_generator import generate_itinerary

st.title("🧳 Local AI Travel Planner")

uploaded_file = st.file_uploader("Upload travel preferences CSV", type="csv")

if uploaded_file:
    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        tmp.write(uploaded_file.read())
        file_path = tmp.name

    data = load_travel_csv(file_path)

    for entry in data:
        st.subheader(entry["city"])

        summary = summarize_notes(entry["notes"])
        itinerary = generate_itinerary(
            entry["city"],
            int(entry["days"]),
            entry["interests"]
        )

        st.markdown("**Summary of preferences:**")
        st.write(summary)

        st.markdown("**Itinerary:**")
        for item in itinerary:
            st.write(item)