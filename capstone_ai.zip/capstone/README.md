# Local AI Travel Planner (Capstone Project)

This project is a fully local AI-powered Python application that:
- Reads travel preferences from a CSV file
- Summarizes user notes using an open-source transformer model
- Generates a day-by-day itinerary
- Displays results in a Streamlit UI

## Setup

```bash
pip install -r requirements.txt